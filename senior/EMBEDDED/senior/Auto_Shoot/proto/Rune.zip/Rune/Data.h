//
// Created by lwk on 2022/5/5.
//
#pragma once

#include "opencv4/opencv2/opencv.hpp"
#include <iostream>
#include<opencv4/opencv2/opencv.hpp>
#include<opencv4/opencv2/highgui.hpp>
#include<thread>
#include <chrono>
#include <vector>
#include <algorithm>


using namespace  cv;
using namespace std;
struct RuneData{
    int exposure_time,gain;
    float predict_time;
    int wb_threshold,rb_threshold;
    int d1,d2,d3;
    int m1,m2,m3;
    bool s_flow ,s_action,s_R,s_A,s_wb,s_rb,show;
    bool dr_Fregion,dr_flow,dr_action,dr_Rregion,dr_R,debug;
    int mask1_d1,mask2_d2,mask3_d3;
    int mask1_e1,mask2_e2,mask3_e3;


    RuneData(){
        FileStorage fin("../Rune/camera-param.yml",FileStorage::READ);
        fin["Qexp"]>>exposure_time;
        fin["Qgain"]>>gain;
        fin["Q_time"] >> predict_time;
        fin["Qwb"]>>wb_threshold;
        fin["Qrb"]>>rb_threshold;
        fin["Qd1"]>>d1;
        fin["Qd2"]>>d2;
        fin["Qd3"]>>d3;
        fin["Qm1"]>>m1;
        fin["Qm2"]>>m2;
        fin["Qm3"]>>m3;
        //是否show
        fin["Q_s_flow"] >> s_flow;
        fin["Q_s_action"]>> s_action;
        fin["Q_s_R"]>> s_R;
        fin["Q_s_A"]>> s_A;
        fin["Q_s_wb"]>> s_wb;
        fin["Q_s_rb"]>>s_rb;
        fin["Q_show"]>>show;
        //是否draw
        fin["Q_dr_Fregion"]>> dr_Fregion;
        fin["Q_dr_flow"] >> dr_flow;
        fin["Q_dr_R"] >> dr_R;
        fin["Q_dr_action"]>> dr_action;
        fin["Q_dr_Rregion"]>> dr_Rregion;

        fin["Q_debug"]>>debug;

        fin["Qmask1_d1"]>>mask1_d1;
        fin["Qmask2_d2"]>>mask2_d2;
        fin["Qmask3_d3"]>>mask3_d3;
        fin["Qmask1_e1"]>>mask1_e1;
        fin["Qmask2_e2"]>>mask2_e2;
        fin["Qmask3_e3"]>>mask3_e3;
        cout<<"exc:"<<exposure_time<<endl;
        cout<<"mask3_e3:"<<mask3_e3<<endl;
        cout<<"mask1_d:"<<mask1_d1<<endl;

    }

};

