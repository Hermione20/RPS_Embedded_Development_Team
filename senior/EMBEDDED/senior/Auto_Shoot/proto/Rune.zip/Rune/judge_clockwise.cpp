//
// Created by lwk on 2022/3/13.
//
#include "Rune.h"
void Rune::collect_angles() {
    if (ag_of_judge.size() < 1) {
        ag_of_judge.push_back(storeData.vane.m_angle);
    } else if (ag_of_judge.size() >= 1) {
        if (fabs(storeData.vane.m_angle - ag_of_judge[ag_of_judge.size() - 1]) < 20) {ag_of_judge.push_back(storeData.vane.m_angle);}
        else {ag_of_judge.clear();}
    }else{std::cout<<"fuck"<<endl;}
}
void Rune::getdirection() {
    for ( int i=0; i < ag_of_judge.size()/2; i++) {
      if (ag_of_judge[i + ag_of_judge.size()/2] - ag_of_judge[i] > 0) {
            clockwise++;//nishizheng
        } else {
            anticlockwise++;//shunshizheng
        }
    }
    if(stop>clockwise && stop>anticlockwise)
    {
        storeData.direction = 0;
    }
    else if(clockwise>anticlockwise){
        storeData.direction = -1;
    }
    else
    {
        storeData.direction = 1;
    }
}
