//
// Created by lwk on 2022/3/13.
//
#include "Rune.h"


void Rune::queue_clear(queue<double> &a) {
    queue<double> empty;
    swap(empty, a);
}

float Rune::makeAngleRegular(float &angle){
    float angle_tmp;
    angle_tmp = fmod(angle, 360);
    if (angle_tmp < 0)
        angle_tmp += 360;
    return angle_tmp;
}
void Rune::get_angle(){
    float t_s_y = target_points[0].y;
    float t_s_x = target_points[0].x;
    //cout<<"is_find_r:"<<storeData.is_find_r<<endl;
    float r_y =R_center.y;
    float r_x = R_center.x;
    float angle = atan2(r_y - t_s_y, t_s_x - r_x) / CV_PI * 180;
    storeData.vane.m_angle = makeAngleRegular(angle);
    //cout<<"m_angle:"<<storeData.vane.m_angle<<endl;
}
void Rune::get_T_and_A(double time){
    if(now_is_fitting ==0) {
        double m_time_span = time;
        if (storeData.times.empty() && storeData.angles.empty()) {
//            cout<<"empty"<<endl;
//            cout<<"m_time1:"<<m_time_span<<endl;
//            cout<<"m_angle1:"<<storeData.vane.m_angle<<endl;
            storeData.times.push(m_time_span);
            storeData.angles.push(storeData.vane.m_angle );
        } else {
            if (storeData.times.back() - storeData.times.front() < 15) {
//                cout<<"m_time2:"<<m_time_span<<endl;
//                cout<<"m_angle2:"<<storeData.vane.m_angle<<endl;
                storeData.times.push(m_time_span);
                storeData.angles.push(storeData.vane.m_angle );
            } else {
                storeData.times.push(m_time_span);
                storeData.time_diff = storeData.times.back() - storeData.times.front();
                maybe_time = (storeData.times.back() + storeData.times.front()) / 2000;
                storeData.times.pop();
                storeData.get_time_diff = 1;
                storeData.angles.push(storeData.vane.m_angle );
                double angle_diff = fabs(storeData.angles.back() - storeData.angles.front());
                int n = int(angle_diff / 72);
                angle_diff = fabs((angle_diff - n * 72));
                if (angle_diff > 68) {
                    angle_diff = fabs(72 - angle_diff);
                }
                //cout<<"time_diff:"<<storeData.time_diff<<endl;
                //cout<<"angle_diff:"<<angle_diff<<endl;
                storeData.angle_diff = angle_diff;
                if (storeData.angle_diff > 20) {
                    storeData.angle_diff=0;
                    add_up++;
                }else{
                    storeData.get_angle_diff = 1;
                }
                storeData.angles.pop();

            }
        }
    }
}

void Rune::get_speed(){
    if(storeData.time_diff !=0) {
        double speed = fabs(((storeData.angle_diff * 3.1415926 / 180) / storeData.time_diff) * 1000);
//        cout<<"speed:"<<speed<<endl;
//        cout<<"speed_times.size:"<<storeData.speed_times.size()<<endl;
        if (0.3 < speed && speed < 3) {
            /*
            *取0.03s内的点，均值滤波，筛选点
            */
            double average_speed =0;
            int average_size = 1;
            if(storeData.speeds.size()>average_size){
                if(storeData.speed_times[storeData.speed_times.size()-1] - storeData.speed_times[0]>0.035) {
                    double last_time = storeData.speed_times[storeData.speed_times.size() - 1];
                    int i = 0;
                    while (true) {
                        i = i + 1;
                        average_speed = average_speed + storeData.speeds[storeData.speeds.size() - 1 - i];
                        double fore_time = storeData.speed_times[storeData.speed_times.size() - 1 - i];
                        //cout<<"fore_time:"<<fore_time<<endl;
                        //用时间定义了容器存放多少
                        if (last_time - fore_time > 0.03) {
                            break;
                        }
                    }
                    //cout<<"i:"<<i<<endl;
                    average_speed = average_speed / i;
                    if (fabs(speed - average_speed) < 0.8) {
                        mutex2.lock();
                        storeData.speeds.push_back(speed);
                        storeData.speed_times.push_back(maybe_time);
//                        cout<<"push3"<<endl;
                        mutex2.unlock();
                    }else{
//                        cout<<"it is noisy data"<<endl;
                    }
                }else{
                    mutex2.lock();
//                    cout<<"push2"<<endl;
                    storeData.speeds.push_back(speed);
                    storeData.speed_times.push_back(maybe_time);
                    mutex2.unlock();
                }
            }else{
                mutex2.lock();
                storeData.speeds.push_back(speed);
                storeData.speed_times.push_back(maybe_time);
//                cout<<"push1"<<endl;
                mutex2.unlock();
            }
        }
    }

}

float Rune::get_distance(Point2f a ,Point2f b) {
    float l=pow(a.x -b.x,2);
    float w=pow(a.y - b.y,2);
    return sqrt(l + w);


}