//
// Created by lwk on 2022/5/23.
//
#include "Rune.h"

void Rune::find_armor(Mat &initial_img, Rect &outer_roi,  Mat &im2show) {

    vector<vector<Point>> contours;
    vector<Vec4i> hierarchy;

    findContours(and_img, contours, hierarchy, RETR_CCOMP, CHAIN_APPROX_NONE);
    if(contours.size()==0) {
        return;
    }
    auto t1 =chrono::high_resolution_clock::now();
    if(data.debug) {
        for (int i = 0; i < contours.size(); i++) {
            if (hierarchy[i][3] < 0) {
                if (0) {
                    cout << "m_hierarchy[i][3]" << hierarchy[i][3] << endl;
                }
                continue;
            }
            //cout<<"m_contours[i].size() "<<contours[i].size()<<endl;
            //在短焦距下可能size会小于50
            if (contours[i].size() < 40) {
                if (0) {
                    cout << "m_contours[i].size() " << contours[i].size() << endl;
                }
                continue;
            }

            // 在短焦距下可能size会小于120
            if (contours[static_cast<uint>(hierarchy[i][3])].size() < 110) {

                continue;
            }
            RotatedRect contour_rect = minAreaRect(contours[i]);
            double area = contour_rect.size.area();
            double contour_area = contourArea(contours[i]);
            //cout<<"armor_area:"<<area<<endl;
            if (area > 1700 && area < 300) {
                continue;
            }
            double length = contour_rect.size.width > contour_rect.size.height ? contour_rect.size.width
                                                                               : contour_rect.size.height;
            double width = contour_rect.size.width < contour_rect.size.height ? contour_rect.size.width
                                                                              : contour_rect.size.height;
            //cout<<"length/width:"<<length/width;
            if (length / width > 2 && length / width < 1.2) {
                continue;
            }
            if (area / contour_area > 1.5) {
                continue;
            }
            Point2f armor_points[4];
            contour_rect.points(armor_points);
            if (data.dr_Fregion) {
                for (int i = 0; i < 4; i++) {
                    line(im2show, armor_points[i] + Point2f(outer_roi.tl()),
                         armor_points[i % 4] + Point2f(outer_roi.tl()), Scalar(0, 255, 0), 4);
                }
            }
            Vane may_target;
            may_target.rect = contour_rect;
            may_target.area = area;
            may_target.length = length;
            may_target.width = width;
            may_target.center = contour_rect.center + Point2f(outer_roi.tl());
            auto t1 = chrono::high_resolution_clock::now();
            find_flow(may_target, initial_img, outer_roi, im2show);
            auto t2 = chrono::high_resolution_clock::now();
            cout << "find_flow" << chrono::duration<double, milli>(t2 - t1).count() << endl;
        }
    }else {
        int i = contours.size();
        cout << "i:" << i << endl;
        tbb::parallel_for(0, i, [&](int i) {
            if (hierarchy[i][3] < 0) {
                if (0) {
                    cout << "m_hierarchy[i][3]" << hierarchy[i][3] << endl;
                }
                return;
            }
            //cout<<"m_contours[i].size() "<<contours[i].size()<<endl;
            //在短焦距下可能size会小于50
            if (contours[i].size() < 40) {
                if (0) {
                    cout << "m_contours[i].size() " << contours[i].size() << endl;
                }
                return;
            }

            // 在短焦距下可能size会小于120
            if (contours[static_cast<uint>(hierarchy[i][3])].size() < 110) {

                return;
            }
            RotatedRect contour_rect = minAreaRect(contours[i]);
            double area = contour_rect.size.area();
            double contour_area = contourArea(contours[i]);
            //cout<<"armor_area:"<<area<<endl;
            if (area > 1700 && area < 300) {
                return;
            }
            double length = contour_rect.size.width > contour_rect.size.height ? contour_rect.size.width
                                                                               : contour_rect.size.height;
            double width = contour_rect.size.width < contour_rect.size.height ? contour_rect.size.width
                                                                              : contour_rect.size.height;
            //cout<<"length/width:"<<length/width;
            if (length / width > 2 && length / width < 1.2) {
                return;
            }
            if (area / contour_area > 1.5) {
                return;
            }
            Point2f armor_points[4];
            contour_rect.points(armor_points);
            if (data.dr_Fregion) {
                for (int i = 0; i < 4; i++) {
                    line(im2show, armor_points[i] + Point2f(outer_roi.tl()),
                         armor_points[i % 4] + Point2f(outer_roi.tl()), Scalar(0, 255, 0), 4);
                }
            }
            Vane may_target;
            may_target.rect = contour_rect;
            may_target.area = area;
            may_target.length = length;
            may_target.width = width;
            may_target.center = contour_rect.center + Point2f(outer_roi.tl());
            auto t1 = chrono::high_resolution_clock::now();
            //cout<<"find_flow"<<endl;
            find_flow(may_target, initial_img, outer_roi, im2show);
            auto t2 = chrono::high_resolution_clock::now();
            double find_flow_ = chrono::duration<double, milli>(t2 - t1).count();
            //cout<<"flow:"<<find_flow_<<endl;

        });
    }
    auto t2 = chrono::high_resolution_clock::now();
    double time_span = chrono::duration<double,milli>(t2-t1).count();
    cout<<"pa_find_flow:"<<time_span<<endl;

}
