//
// Created by lwk on 2022/4/25.
//

#include <iostream>
#include "Rune.h"
using namespace chrono;
void Rune::show_debug() {
    if(data.debug){
        namedWindow("im2show", 0);
        resizeWindow("im2show", 800, 700);

        namedWindow("wb",0);
        resizeWindow("wb",800,600);

        namedWindow("rb",0);
        resizeWindow("rb",800,650);

        namedWindow("and_img",0);
        resizeWindow("and_img",800,650);

        namedWindow("flow",0);
        resizeWindow("flow",800,600);

        namedWindow("r1",0);
        resizeWindow("r1",800,600);

        namedWindow("is_action",0);
        resizeWindow("is_action",800,600);

        cv::createTrackbar("threshold","wb",&data.wb_threshold,255);
        cv::createTrackbar("threshold","rb",&data.rb_threshold,255);
        cv::createTrackbar("d1","wb",&data.d1,4);
        cv::createTrackbar("m1","wb",&data.m1,4);
        cv::createTrackbar("d2","rb",&data.d2,4);
        cv::createTrackbar("m2","rb",&data.m2,4);
        cv::createTrackbar("d3","and_img",&data.d3,4);
        cv::createTrackbar("m3","and_img",&data.m3,4);
        cv::createTrackbar("mask_d1","flow",&data.mask1_d1,4);
        cv::createTrackbar("mask_e1","flow",&data.mask1_e1,4);
        cv::createTrackbar("mask_d2","r1",&data.mask2_d2,4);
        cv::createTrackbar("mask_e2","r1",&data.mask2_e2,4);
        cv::createTrackbar("mask_d3","is_action",&data.mask3_d3,4);
        cv::createTrackbar("mask_e3","is_action",&data.mask3_e3,4);
    }
}
void Rune::run(int color, int mode, Mat &initial_img) {
    start_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> time_span = start_time - t1;
    double m_time_span = (double) time_span.count();
    cout << "m_time_span:" << m_time_span << endl;
    Mat im2show = initial_img;
    if(!initial_img.empty()) {
        //cout<<"why"<<endl;
        double predict_x = 0.5*initial_img.cols;
        double predict_y = 0.5*initial_img.rows;
        if (mode == 1) {
            big_run(m_time_span, initial_img, predict_x,predict_y,color,im2show);
        } else {
            small_run(m_time_span, initial_img, predict_x,predict_y,color,im2show);
        }
        auto end_time = chrono::high_resolution_clock::now();
        int time_span = chrono::duration<double,milli>(end_time - start_time).count();
        if(time_span < 10){
            int wait_time = 10 - time_span;
            this_thread::sleep_for(milliseconds(wait_time));
        }
        if(data.show) {
            imshow("im2show", im2show);
        }
    }
}
