//
// Created by lwk on 2022/3/13.
//
#include "Rune.h"

void Rune::process(Mat &initial_img,int &color) {
    cv::cvtColor(initial_img,binary_img, COLOR_BGR2GRAY);
    cv::threshold(binary_img, binary_img, data.wb_threshold, 255, THRESH_BINARY);
    auto t1 = chrono::high_resolution_clock::now();
    std::vector<cv::Mat> channels;
    cv::split(initial_img, channels);
    Mat split_img;
    if (color >100)
    {
        split_img = channels.at(0) - channels.at(2);//bgr
    }
    else
    {
        split_img = channels.at(2) - channels.at(0);
    }
    cv::threshold(split_img, binary_color_img, data.rb_threshold, 255, THRESH_BINARY);
    bitwise_and(binary_img,binary_color_img,and_img);
    if(data.m3 == 1) {morphologyEx(and_img, and_img, MORPH_CLOSE, element1);}
    else if(data.m3 == 2){morphologyEx(and_img, and_img, MORPH_CLOSE, element2);}
    else if(data.m3 == 3){morphologyEx(and_img, and_img, MORPH_CLOSE, element3);}
    else{}

    if(data.d3 == 1) {dilate(and_img, and_img, element1);}
    else if(data.d3 == 2){dilate(and_img,and_img,element2);}
    else if(data.d3 == 3){dilate(and_img,and_img,element3);}
    else if(data.d3 == 4){dilate(and_img,and_img,element4);}
    else{}
    auto t2 = chrono::high_resolution_clock::now();
    cout<<"process_two:"<<chrono::duration<double,milli>(t2-t1).count()<<endl;
    if(data.s_rb){
        imshow("rb",binary_color_img);
    }
}
void Rune::recognize(Mat &initial_img, Mat &im2show,int &color) {
    Rect outer_roi = Rect(Point(0,0),Point(initial_img.cols,initial_img.rows));
    if(add_up < 3){
        cout<<"aha"<<endl;
        int x = R_center.x - storeData.distance*1.5 > 0?R_center.x - storeData.distance*1.5:0;
        int y = R_center.y - storeData.distance*1.5 > 0? R_center.y - storeData.distance*1.5:0;
        if(x > initial_img.cols){ x = initial_img.cols;}
        if(y > initial_img.rows){ y = initial_img.rows;}
        int x1 = R_center.x + storeData.distance*1.5 < initial_img.cols? R_center.x + storeData.distance*1.5:initial_img.cols;
        int y1 = R_center.y + storeData.distance*1.5 < initial_img.rows? R_center.y + storeData.distance*1.5:initial_img.rows;
        if(x1 < 0){ x = 0;}
        if(y1 <0){ y = 0;}
        Point tl(x,y);
        Point br(x1,y1);
        if(x1 >x && y1>y) {
            outer_roi = Rect(tl, br);
        }else{
            outer_roi = Rect(Point(0,0),Point(initial_img.cols,initial_img.rows));
        }
    }
    initial_img = Mat(initial_img,outer_roi);
    may_targets.clear();
    not_target.clear();
    R_points.clear();
    target_points.clear();
    Point2f a = outer_roi.tl();
    Point2f b = Point2f (outer_roi.tl().x + outer_roi.width,outer_roi.tl().y);
    Point2f c = Point2f (outer_roi.tl().x + outer_roi.width,outer_roi.tl().y + outer_roi.width);
    Point2f d = Point2f (outer_roi.tl().x , outer_roi.tl().y + outer_roi.width);
    line(im2show,a,b,Scalar(255,255,255),3);
    line(im2show,b,c,Scalar(255,255,255),3);
    line(im2show,c,d,Scalar(255,255,255),3);
    line(im2show,d,a,Scalar(255,255,255),3);

    auto t1 =chrono::high_resolution_clock::now();
    process(initial_img,color);
    auto t2 = chrono::high_resolution_clock::now();
    if(data.s_A) {imshow("and_img", and_img);}
    //auto t1 =chrono::high_resolution_clock::now();
    find_armor(initial_img,outer_roi,im2show);
//    auto t2 = chrono::high_resolution_clock::now();
//    cout<<"find_armor:"<<chrono::duration<double,milli>(t2-t1).count()<<endl;
}