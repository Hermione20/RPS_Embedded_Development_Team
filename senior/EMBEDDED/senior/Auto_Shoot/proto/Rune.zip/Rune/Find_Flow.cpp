//
// Created by lwk on 2022/5/23.
//
#include "Rune.h"
void Rune::dm_r2(Mat &r2, int d, int m) {
    if(data.mask3_d3 ==1){dilate(r2,r2,element1);}
    else if(data.mask3_d3 == 2) {dilate(r2, r2, element2);}
    else if(data.mask3_d3 ==3){dilate(r2,r2,element3);}else{}

    if(data.mask3_e3 ==1){erode(r2,r2,element1);}
    else if(data.mask3_e3 == 2){erode(r2, r2, element2);}
    else if(data.mask3_e3 ==3){erode(r2,r2,element3);}else{}
}
void Rune::mask3_process(Vane &m_target, Mat &r2, RotatedRect &flow_rect, Mat &initial_img, double &mask3_area, Mat &im2show,Rect &outer_roi,Rect &roi) {
    //6mm :width = m_target.length*0.65;
    //4mm :width = m_target.length*0.8;
    double width = m_target.length*0.65;
    double length = max(flow_rect.size.height, flow_rect.size.width) * 0.6;
    double angle = flow_rect.angle/180*CV_PI;
    Point2f  flow_center_ = m_target.flow_center - Point2f (outer_roi.tl());
    int x = flow_center_.x - length >0?flow_center_.x - length:0;
    int y = flow_center_.y - length > 0?flow_center_.y - length:0;
    if(x > and_img.cols){x = and_img.cols;}
    if( y > and_img.rows){ y =and_img.rows;}
    int x1 = flow_center_.x + length < and_img.cols?flow_center_.x + length:and_img.cols;
    int y1 = flow_center_.y + length < and_img.rows?flow_center_.y + length:and_img.rows;
    if(x < 0){x = 0;}
    if(y<0){y = 0;}
    Point tl = Point(x,y);
    Point dr = Point(x1,y1);
    if(dr.x > tl.x && dr.y > tl.y) {
        roi = Rect(tl, dr);
    }else{
        roi = Rect(Point(0,0),Point(and_img.cols,and_img.rows));
    }
    Mat mask3_image = Mat(and_img,roi);
    /*
     * 创建action掩码
     */
    Point2f mask3_rect[4];
    double mask3_width = flow_rect.size.width;
    double mask3_length = flow_rect.size.height;
    if (mask3_width < mask3_length) {
        mask3_rect[0] = Point2f(m_target.flow_center.x + width * cos(angle) + length * sin(angle),
                                m_target.flow_center.y + width * sin(angle) - length * cos(angle));
        mask3_rect[1] = Point2f(m_target.flow_center.x + width * cos(angle) - length * sin(angle),
                                m_target.flow_center.y + width * sin(angle) + length * cos(angle));
        mask3_rect[2] = Point2f(m_target.flow_center.x - width * cos(angle) - length * sin(angle),
                                m_target.flow_center.y - width * sin(angle) + length * cos(angle));
        mask3_rect[3] = Point2f(m_target.flow_center.x - width * cos(angle) + length * sin(angle),
                                m_target.flow_center.y - width * sin(angle) - length * cos(angle));
    } else {
        mask3_rect[0] = Point2f(m_target.flow_center.x + width * sin(angle) - length * cos(angle),
                                m_target.flow_center.y - width * cos(angle) - length * sin(angle));
        mask3_rect[1] = Point2f(m_target.flow_center.x + width * sin(angle) + length * cos(angle),
                                m_target.flow_center.y - width * cos(angle) + length * sin(angle));
        mask3_rect[2] = Point2f(m_target.flow_center.x - width * sin(angle) + length * cos(angle),
                                m_target.flow_center.y + width * cos(angle) + length * sin(angle));
        mask3_rect[3] = Point2f(m_target.flow_center.x - width * sin(angle) - length * cos(angle),
                                m_target.flow_center.y + width * cos(angle) - length * sin(angle));
    }

    mask3_area = sqrt(pow(mask3_rect[0].x-mask3_rect[1].x,2)+pow(mask3_rect[0].y - mask3_rect[1].y,2)) * sqrt(pow(mask3_rect[2].x-mask3_rect[1].x,2)+pow(mask3_rect[2].y - mask3_rect[1].y,2));
    Mat mask3 = Mat(mask3_image.rows, mask3_image.cols, CV_8UC1, Scalar(0, 0, 0));
    if(data.dr_action) {
        for (int j = 0; j < 4; j++) {
            line(im2show, mask3_rect[j], mask3_rect[(j + 1) % 4], Scalar(0, 0, 255), 2, 8);  //绘制最小外接矩形每条边
        }
    }
    Point root_points[1][4];
    root_points[0][0] = mask3_rect[0] - Point2f(outer_roi.tl()) - Point2f (roi.tl());
    root_points[0][1] = mask3_rect[1] - Point2f (outer_roi.tl()) - Point2f (roi.tl());
    root_points[0][2] = mask3_rect[2] - Point2f (outer_roi.tl()) - Point2f (roi.tl());
    root_points[0][3] = mask3_rect[3] - Point2f (outer_roi.tl()) - Point2f (roi.tl());
    const Point* ppt[1] = { root_points[0] };
    int npt[] = { 4 };
    cv::fillPoly(mask3, ppt, npt, 1, Scalar(255, 255, 255));
    bitwise_and(mask3, mask3_image, r2);
    dm_r2(r2,data.d2,data.m2);

}
void Rune::judge_action( Rect &outer_roi, bool &Inaction, Vane &m_target, RotatedRect &flow_rect, Mat &initial_img, Mat &im2show) {
    /*
     * 框定roi
     */
    Mat r2;
    double mask3_area;
    Rect roi;
    mask3_process(m_target,r2,flow_rect,initial_img,mask3_area,im2show,outer_roi,roi);
    if(data.s_action) {
        imshow("is_action", r2);
    }
    /*
     * 在框定的roi中判断是否激活
     */
    vector<vector<Point>> judge_contours;
    vector<Vec4i> judge_hierarchy;
    findContours(r2, judge_contours, judge_hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE);
    bool In_condition1 =0;
    bool In_condition2 = 0;
    bool A_condition1 = 0;
    bool A_condition2 = 0;
    if(judge_contours.size() !=0) {
        double all_area = 0;
        for (int i = 0; i < judge_contours.size(); i++) {
            double contour_area = contourArea(judge_contours[i]);
            all_area = all_area + contour_area;
            //cout << "contourArea(judge_contours[i]):" << contour_area << endl;
            //cout << "mask3_area / contourArea(judge_contours[i]:" << mask3_area / contourArea(judge_contours[i])<< endl;
            //6mm:mask3_area / contourArea(judge_contours[i]) < 5.1
            //4mm:mask3_area / contourArea(judge_contours[i]) < 3.7
            if (mask3_area / contourArea(judge_contours[i]) < 5.1 && mask3_area / contourArea(judge_contours[i]) >= 2.4) {
                In_condition1 = 1;
            }
            if(mask3_area / contourArea(judge_contours[i]) < 2.4 && mask3_area / contourArea(judge_contours[i]) > 1){
                A_condition1 =1;
            }
        }
        //cout<<"mask3_area:"<<mask3_area<<endl;
        //cout << "all_area:" << all_area << endl;
        //cout << "mask3_area / all_area:" << mask3_area / all_area << endl;
        //高曝光下可能到2.5 - 3
        //高膨胀下可能到3.2-3.7
        //6mm:mask3_area / all_area >= 3.7
        //4mm:mask3_area / all_area >= 2.4
        if (mask3_area / all_area >= 2.4 ) {
            In_condition2 = 1;
        }else if(mask3_area / all_area < 2.4 && mask3_area /all_area > 1){
            A_condition2 = 1;
        }else{
        }
        if(In_condition1 == 1 && In_condition2 ==1){
            Inaction = 1;
            m_target.is_Inaction = 1;
            if(data.debug) {
                putText(im2show, "Inaction", m_target.flow_center, 1, 1, Scalar(255, 255, 255), 2);
                putText(im2show, "ratio" + to_string(mask3_area / all_area), m_target.flow_center, 2, 2,
                        Scalar(255, 255, 255), 2);
            }
            may_targets.push_back(m_target);
            target_points.push_back(m_target.center );
        }else if(A_condition1 == 1 && A_condition2 == 1){
            m_target.is_Inaction = 0;
            //6mm:mask3_area / all_area =1.4;
            if(data.debug) {
                putText(im2show,"Action",m_target.flow_center,1,1,Scalar(255,255,255),2);
                putText(im2show,"ratio" + to_string( mask3_area / all_area) ,m_target.flow_center,2,2,Scalar(255,255,255),2);
            }
            not_target.push_back(m_target);
        }else{
            if(data.debug) {
            putText(im2show,"UNKNOWN",m_target.flow_center,1,1,Scalar(255,255,255),2);
            }
        }
    }

}
void Rune::dm_r(Mat &r, int d, int m) {
    if(data.mask1_d1==1){
        dilate(r,r,element1);
    }else if(data.mask1_d1 == 2) {
        dilate(r, r, element2);
    }else if(data.mask1_d1==3){
        dilate(r,r,element3);
    }else{
    }
    if(data.mask1_e1==1){
        erode(r,r,element1);
    }else if(data.mask1_e1 == 2) {
        erode(r, r, element2);
    }else if(data.mask1_e1==3){
        erode(r,r,element3);
    }else{
    }
}
void Rune::mask_process(Vane &m_target, Rect &outer_roi, Mat &initial_img, Mat &r, double &mask_area, Rect &roi, Mat &im2show) {
    //6mm :mask_l = m_target.length*2.4;
    //4mm :mask_l = m_target.length*3;
    double mask_l = m_target.length*2.4;
    double mask_w = m_target.width*0.5;
    RotatedRect box1 = m_target.rect;
    Point2f target_center = m_target.center - Point2f (outer_roi.tl());
    ////
    /*
     * 框定roi
     */
    ////
    int x1 = target_center.x - mask_l > 0?target_center.x - mask_l:0;
    int y1 =target_center.y - mask_l > 0?target_center.y - mask_l:0;
    if(x1 > and_img.cols){x1 = and_img.cols;}
    if(y1 > and_img.rows){x1 = and_img.rows;}
    int x2 = target_center.x + mask_l < and_img.cols?target_center.x + mask_l:and_img.cols;
    int y2 = target_center.y + mask_l < and_img.rows?target_center.y + mask_l:and_img.rows;
    if(x2 < 0){x2 = 0;}
    if(y2 < 0){y2 = 0;}
    Point2f lt = Point2f(x1,y1);
    Point2f rd = Point2f(x2,y2);

    if(rd.x > lt.x && rd.y > lt.y) {
        roi = Rect(lt, rd);
    }else{
        roi = Rect(Point(0,0),Point(and_img.cols,and_img.rows));
    }
    Mat binary_roi = Mat(and_img,roi);
    //imshow("binary",binary_roi);
    Mat mask(binary_roi.rows,binary_roi.cols,CV_8UC1,Scalar(0,0,0));
    ////
    /*
     * 创建flow掩码
     */
    Point2f rect[4];
    box1.points(rect);
    Point2f mask_point[4];
    if(box1.size.width > box1.size.height) {
        double angle = CV_PI/2 - box1.angle/180*CV_PI;
        mask_point[0] = Point2f(target_center.x - mask_l * cos(angle) + mask_w * sin(angle),
                                target_center.y + mask_l * sin(angle) + mask_w * cos(angle));
        mask_point[1] = Point2f(target_center.x - mask_l * cos(angle) - mask_w * sin(angle),
                                target_center.y + mask_l * sin(angle) - mask_w * cos(angle));
        mask_point[3] = Point2f(target_center.x + mask_l * cos(angle) + mask_w * sin(angle),
                                target_center.y - mask_l * sin(angle) + mask_w * cos(angle));
        mask_point[2] = Point2f(target_center.x + mask_l * cos(angle) - mask_w * sin(angle),
                                target_center.y - mask_l * sin(angle) - mask_w * cos(angle));
    }else{
        double angle = CV_PI/2 - box1.angle/180*CV_PI;
        mask_point[0] = Point2f(target_center.x + mask_w * cos(angle) + mask_l * sin(angle),
                                target_center.y - mask_w * sin(angle) + mask_l * cos(angle));
        mask_point[1] = Point2f(target_center.x + mask_w * cos(angle) - mask_l * sin(angle),
                                target_center.y - mask_w * sin(angle) - mask_l * cos(angle));
        mask_point[3] = Point2f(target_center.x - mask_w * cos(angle) + mask_l * sin(angle),
                                target_center.y +
                                mask_w * sin(angle) + mask_l * cos(angle));
        mask_point[2] = Point2f(target_center.x - mask_w * cos(angle) - mask_l * sin(angle),
                                target_center.y + mask_w * sin(angle) - mask_l * cos(angle));
    }
    for(int j=0;j<4;j++) {
        //line(im2show, mask_point[j] +Point2f (outer_roi.tl()), mask_point[(j + 1) % 4] + Point2f (outer_roi.tl()), Scalar(0, 255, 0), 2, 8);
    }
    double distance1 = sqrt((pow(mask_point[0].x - mask_point[1].x,2) + pow(mask_point[0].y - mask_point[1].y,2)));
    double distance2= sqrt((pow(mask_point[1].x - mask_point[2].x,2) + pow(mask_point[1].y - mask_point[2].y,2)));
    mask_area = distance1*distance2;
    Point root_points[1][4];
    root_points[0][0] = mask_point[0] - lt ;
    root_points[0][1] = mask_point[1] - lt;
    root_points[0][2] = mask_point[2] - lt;
    root_points[0][3] = mask_point[3] - lt;
    const Point* ppt[1] = { root_points[0] };
    int npt[] = { 4 };
    cv::fillPoly(mask, ppt, npt, 1, Scalar(255, 255, 255));
    auto t1 = chrono::high_resolution_clock::now();
    bitwise_and(mask,binary_roi,r);
    dm_r(r,data.d1,data.m1);
    auto t2 = chrono::high_resolution_clock::now();
    //cout<<"bit_and:"<<chrono::duration<double,milli>(t2-t1).count()<<endl;
}

void Rune::find_flow(Vane m_target, Mat &initial_img, Rect &outer_roi, Mat &im2show) {
    double length = m_target.length;
    double width = m_target.width;
    Mat r;
    double area = m_target.area;
    double mask_area;
    Rect roi;
    mask_process(m_target,outer_roi,initial_img,r,mask_area,roi,im2show);
    if(data.s_flow) {
        imshow("flow", r);
    }
    ////
    /*
     * 在掩码中寻找流动灯条
     */
    ////
    vector<vector<Point>> m_contours;
    vector<Vec4i> m_hierarchy;
    findContours(r, m_contours, m_hierarchy, RETR_EXTERNAL, CHAIN_APPROX_NONE);
    if(m_contours.size()>0) {
        for (int i = 0; i < m_contours.size(); i++) {
            RotatedRect contour_rect = minAreaRect(m_contours[i]);
            double con_length = max(contour_rect.size.width, contour_rect.size.height);
            double con_width = min(contour_rect.size.width, contour_rect.size.height);
            double con_l_w_ratio = con_length / con_width;
            //cout << "con_l_w_ratio:" << con_l_w_ratio << endl;
            double contour_area = contourArea(m_contours[i]);
            //cout << "contour_area:" << contour_area << endl;
            double size_area = contour_rect.size.area();
            double s_a_ratio = size_area / contour_area;
            //cout << "s_a_ratio:" << s_a_ratio << endl;
            if (s_a_ratio > 2.7) {
                //putText(im2show, "s_a_ratio:" + to_string(s_a_ratio),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }
            if (con_l_w_ratio < 1.5 || con_l_w_ratio > 8) {
                //putText(im2show, "con_l_w_ratio:" + to_string(con_l_w_ratio),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }
            if (contour_area < 500 || contour_area > 3000) {
                //putText(im2show, "contour_area:" + to_string(contour_area),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }
            double m_a_ratio = mask_area / contour_area;
            //cout<<"m_a_ratio:"<<m_a_ratio<<endl;
            if(m_a_ratio > 9 && m_a_ratio <3.5){
                //putText(im2show, "m_a_ratio:" + to_string(m_a_ratio),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }
            double area_ratio = contour_area / area;
            //cout << "area_ratio:" << area_ratio << endl;
            if (area_ratio > 3 || area_ratio < 0.7) {
                //cout<<"area_ratio:"<<area_ratio<<endl;
                //putText(im2show, "area_ratio:" + to_string(area_ratio),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }

            double l_ratio = con_length / length;
            //putText(initial_img,"l_ratio:" + to_string(l_ratio),contour_rect.center + Point2f(roi.tl()),2,2,Scalar(255,255,255));
            //cout << "l_ratio:" << l_ratio << endl;
            //在图像特征较为明显的时候 两个轮廓的长之比可能只有1.9
            if (l_ratio > 4.5 || l_ratio < 1.6) {
                //putText(im2show, "l_ratio:" + to_string(l_ratio),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }

            double w_ratio = con_width / width;
            //putText(initial_img,"w_ratio:" + to_string(w_ratio),contour_rect.center + Point2f(roi.tl()),2,2,Scalar(255,255,255));
            //cout << "w_ratio:" << w_ratio << endl;
            if (w_ratio >= 2 || w_ratio < 0.5) {
                //putText(im2show, "w_ratio:" + to_string(w_ratio),contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl()),2,2,Scalar(255,255,255),2);
                continue;
            }
            Point2f flow_points[4];
            contour_rect.points(flow_points);
            if(data.dr_flow) {
                for (int j = 0; j < 4; j++) {
                    line(im2show, flow_points[j] + Point2f(roi.tl()) + Point2f(outer_roi.tl()),
                         flow_points[(j + 1) % 4] + Point2f(roi.tl()) + Point2f(outer_roi.tl()), Scalar(255, 0, 0), 2,
                         8);
                }
            }
            bool Inaction =0;
            //将坐标回归到最原始坐标
            Point2f flow_center = contour_rect.center + Point2f (roi.tl()) +Point2f (outer_roi.tl());
            m_target.flow_center = flow_center;
            ////判断是否激活
            judge_action(outer_roi,Inaction,m_target,contour_rect,initial_img,im2show);
            if(Inaction) {
                circle(im2show, m_target.center, 4, Scalar(0, 255, 0), 2, 8);  //绘制最小外接矩形的中心点
                find_r(flow_center,outer_roi, m_target, initial_img,im2show);
            }else{
                not_target.push_back(m_target);
            }
        }

    }
}