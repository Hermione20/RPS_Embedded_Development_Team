//
// Created by lwk on 2022/5/23.
//
#include "Rune.h"
void Rune::dm_r1(Mat &r1, int d, int m) {
    if(data.mask2_d2 ==1){
        dilate(r1,r1,element1);
    }else if(data.mask2_d2 == 2) {
        dilate(r1, r1, element2);
    }else if(data.mask3_d3 ==3){
        dilate(r1,r1,element3);
    }else{
        //cout<<"mask3 no dilate"<<endl;
    }
    if(data.mask2_e2 ==1){
        erode(r1,r1,element1);
    }else if(data.mask2_e2 == 2) {
        erode(r1, r1, element2);
    }else if(data.mask2_e2 ==3){
        erode(r1,r1,element3);
    }else{
        //cout<<"mask3 no erode"<<endl;
    }
}
void Rune::mask2_process(Point2f r_circle, Mat &r1, double length, Rect &roi, Rect &outer_roi, Mat &im2show) {
    /*
     * 框定roi，防止越界
     */
    r_circle =r_circle - Point2f (outer_roi.tl());
    int x = r_circle.x - length*0.7 > 0?r_circle.x - length*0.7:0;
    int y = r_circle.y - length*0.7 > 0?r_circle.y - length*0.7:0;
    if(x >and_img.cols){ x = and_img.cols;}
    if(y > and_img.rows){ y = and_img.rows;}
    int x1 = r_circle.x + length*0.7 < and_img.cols?r_circle.x + length*0.7:and_img.cols;
    int y1 = r_circle.y + length*0.7 < and_img.rows?r_circle.y + length*0.7:and_img.rows;
    if(x1 <0){ x1 = 0;}
    if(y1 <0){ y1 = 0;}
    Point tl = Point (x,y);
    Point dr = Point(x1,y1);
    if(dr.x > tl.x && dr.y > tl.y) {
        roi = Rect(tl, dr);
    }else{
        roi = Rect(Point(0,0),Point(and_img.cols,and_img.rows));
    }
    Mat roi_image  = Mat(and_img,roi);
    if(data.dr_Rregion) {
        circle(im2show, r_circle + Point2f(outer_roi.tl()), length * 0.5, Scalar(0, 255, 0), 2);
    }
    Mat mask2 =  Mat(roi_image.rows,roi_image.cols,CV_8UC1,Scalar(0,0,0));
    circle(mask2, r_circle-Point2f (roi.tl()), length * 0.5, Scalar(255, 255, 255), -1);
    bitwise_and(mask2,roi_image,r1);
    dm_r1(r1,data.d2,data.m2);

}
void Rune::find_r(Point2f flow_center, Rect &outer_roi, Vane m_target, Mat &initial_img,  Mat &im2show) {
    RotatedRect box1 = m_target.rect;
    double length = m_target.length;
    cv::Point2f p2p(flow_center - (box1.center + Point2f(outer_roi.tl())));
    Point2f m_r_center = flow_center + p2p * 1.5 ;
    Mat r1;
    auto t1 =chrono::high_resolution_clock::now();
    Rect roi;
    mask2_process(m_r_center,r1,length,roi,outer_roi,im2show);
    if(data.s_R) {
        if (!r1.empty()) {
            imshow("r1", r1);
        }
    }
    auto t2 = chrono::high_resolution_clock::now();
    Point2f r_center;
    vector<vector<Point>> center_R_contours;
    findContours(r1,center_R_contours,RETR_EXTERNAL,CHAIN_APPROX_NONE);
    for ( int i=0;i<center_R_contours.size();i++) {
        double r_area = contourArea(center_R_contours[i]);
        RotatedRect r_rect = minAreaRect(center_R_contours[i]);
        //高膨胀加长焦可能到600
        //cout << "r_area:" << r_area << endl;
        if (r_area < 60 || r_area > 550) {
            continue;
        }
        double r_length = max(r_rect.size.width, r_rect.size.height);
        double r_width = min(r_rect.size.width, r_rect.size.height);
        double r_lw_ratio = r_length / r_width;
        //cout << "r_lw_ratio:" << r_lw_ratio << endl;
        if (r_lw_ratio > 2 || r_lw_ratio <1) {
            continue;
        }
        //cout << "r_area_size_ratio:" << r_rect.size.area() / r_area << endl;
        if (r_rect.size.area() / r_area > 1.6) {
            continue;
        }
        //cout<<"is_find_r"<<is_find_r<<endl;
        r_center = r_rect.center + Point2f(roi.tl()) +Point2f (outer_roi.tl());
        R_points.push_back(r_center);
    }
}
void Rune::select_r(vector<Point2f> &R_points,Mat &im2show) {
    if(R_points.size() > 1 || R_points.size() ==0) {
        if (not_target.size() > 0 && may_targets.size() > 0) {
            if (R_points.size() > 1) {
                int size = R_points.size();
                double distacne_diff = 15;
                for (int i = 0; i < size; i++) {
                    Point2f may_R = R_points[i];
                    double distance1 = get_distance(may_R, may_targets[0].center );
                    double distance0 = get_distance(may_R, not_target[0].center);
                    double m_distance_diff = fabs(distance1 - distance0);
                    if (m_distance_diff < distacne_diff) {
                        distacne_diff = m_distance_diff;
                        R_center = may_R;

                    }
                }
            }
            if(R_points.size() ==0) {
                int x1 = may_targets[0].center.x;
                int y1 = may_targets[0].center.y;
                int x2 = may_targets[0].flow_center.x;
                int y2 = may_targets[0].flow_center.y;
                int x3 = not_target[0].center.x;
                int y3 = not_target[0].center.y;
                int x4 = not_target[0].flow_center.x;
                int y4 = not_target[0].flow_center.y;
                if (x1 - x2 != 0 && x3 - x4 != 0 ) {
                    double k1 = (y1 - y2) / (x1 - x2);
                    double k2 = (y3 - y4) / (x3 - x4);
                    R_center.x = (k2 * x3 - k1 * x1 + y1 - y3) / (k2 - k1);
                    R_center.y = (k1 * y3 - k2 * y1 + k1 * k2 * x1 - k1 * k2 * x3) / (k1 - k2);
                }
            }
        }
    }else{
        R_center =R_points[0];
    }
    if(data.dr_R) {
        circle(im2show, R_center, 20, Scalar(0, 255, 0), 2);
    }

}