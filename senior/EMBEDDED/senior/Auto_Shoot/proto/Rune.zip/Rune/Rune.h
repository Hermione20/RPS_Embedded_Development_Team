//
// Created by lwk on 2022/3/15.
#ifndef RUNE_RUNE_H
#define RUNE_RUNE_H

#include "opencv4/opencv2/opencv.hpp"
#include <iostream>
#include<opencv4/opencv2/opencv.hpp>
#include<opencv4/opencv2/highgui.hpp>
#include<thread>
#include <chrono>
#include <vector>
#include <algorithm>
#include "math.h"
#include "Data.h"
#include <tbb/parallel_for.h>
#include <tbb/parallel_for_each.h>

using namespace cv;
using namespace std;

typedef enum
{
    UNKNOWN,   //未知类型
    INACTION, //未激活
    ACTION    //已激活
} Type;
static Mat element1 = getStructuringElement(MORPH_RECT, Size(1, 1));//设置内核1
static Mat element2 = getStructuringElement(MORPH_RECT, Size(3, 3));//设置内核2
static Mat element3 = getStructuringElement(MORPH_RECT, Size(5, 5));//设置内核3
static Mat element4 = getStructuringElement(MORPH_RECT, Size(7, 7));


class Vane
{
public:
    Vane() {
        m_type =UNKNOWN;
    }
    RotatedRect rect;
    double width;
    double length;
    double area;
    Point2f center;
    Point2f flow_center;
    bool is_Inaction;
    int m_type ;                  //扇叶类型
    float m_angle;                //扇叶角度
    double m_time;                //时间戳(s)
    double m_rate;                //扇叶亮度
};

class Store_Data{
public:
    Vane vane;
    Vane last_target;

    queue<double> times;
    queue<double> angles;

    double angle_diff = 1 ;
    double time_diff = 1;
    vector<double> speeds;
    vector<double> speed_times;

    Point2f R_center_point;
    bool get_angle_diff = 0;
    bool get_time_diff = 0;
    float predict_angle;
    float distance;
    float C,theta,D;
    float frequency = 1.94;
    int direction =0;

};


class Rune{
public:
    Rune(){
        FileStorage fin("../Rune/camera-param.yml",FileStorage::READ);
        t1 = std::chrono::high_resolution_clock::now();
    }
    /*
     * 可能需要换的参数
     */

    chrono::high_resolution_clock::time_point t1;
    mutex mutex2;
    Mat picture;



    Store_Data storeData;
    RuneData data;
    Mat binary_img,binary_color_img,and_img;


    double interval_time;

    vector<Point2f> R_points;
    Point2f R_center;
    vector<Point2f> target_points;
    vector<Vane> may_targets;
    vector<Vane> not_target;

    vector<float> ag_of_judge;
    int stop = 0;
    int clockwise = 0;
    int anticlockwise = 0;
    int add_up = 0;
    bool fit_one = 1;

    double maybe_time;
    bool is_fitted =0;
    bool now_is_fitting = 0;
    int small_rune_speed = 60;

    chrono::high_resolution_clock::time_point start_time ;

public:
    void dm_r(Mat &r,int d,int m);
    void dm_r1(Mat &r1,int d,int m);
    void dm_r2(Mat &r2,int d,int m);
    void process(Mat &initial_img,int &color);
    void mask_process(Vane &m_target, Rect &outer_roi, Mat &initial_img, Mat &r, double &mask_area, Rect &roi, Mat &im2show);

    void mask2_process(Point2f r_circle,Mat &r1,double length,Rect &roi,Rect &outer_roi,Mat &im2show);
    void mask3_process( Vane &m_target, Mat &r2, RotatedRect &flow_rect, Mat &initial_img, double &mask3_area, Mat &im2show,Rect &outer_roi,Rect &roi);
    void find_armor(Mat &initial_img,Rect &outer_roi,Mat &im2show);
    void find_flow(Vane m_target, Mat &initial_img, Rect &outer_roi, Mat &im2show);
    void judge_action(Rect &outer_roi, bool &Inaction, Vane &m_target, RotatedRect &flow_rect, Mat &initial_img, Mat &im2show);
    void find_r(Point2f flow_center, Rect &outer_roi, Vane m_target, Mat &initial_img, Mat &im2show);
    void select_r(vector<Point2f> & R_points,Mat &im2show);
    void recognize(Mat &initial_img,Mat & im2show,int &color);

    float get_distance(Point2f a,Point2f b);
    void queue_clear(queue<double> &a);
    void get_angle();
    void get_T_and_A(double time);
    void get_speed();

    float makeAngleRegular(float &angle);
    void collect_angles();
    void getdirection();

    void fit_way();
    void fitting();

    void big_predict(Mat &im2show,double &predict_x,double &predict_y);
    void small_predict(Mat &im2show,double &predict_x,double &predict_y);
    void big_run(double m_time_span,Mat & img,double &x,double &y,int color,Mat &im2show);
    void small_run(double m_time_span,Mat & img,double &x,double &y,int color,Mat &im2show);
    void run(int color,int mode,Mat &initial_img);
    void show_debug();
};



#endif RUNE_RUNE_H
