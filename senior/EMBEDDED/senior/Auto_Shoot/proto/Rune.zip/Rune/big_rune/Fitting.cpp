#include "../Rune.h"

//void Rune::denoise() {
//    int s_size = data.denoise_samplesize;
//    Mat X = Mat::zeros(s_size, s_size, CV_64FC1);
//    Mat Y = Mat::zeros(s_size, 1, CV_64FC1);
//
//    for (int i = 0; i < s_size; i++)
//        for (int j = 0; j < s_size; j++)
//            for (int k = 0; k < storeData.speed_times.size(); k++) {
//                X.at<double>(i, j) = X.at<double>(i, j) + pow(storeData.speed_times[k], j + i);
//            }
//    for (int i = 0; i < s_size; i++) {
//        for (int k = 0; k < storeData.speeds.size(); k++) {
//            //cout << Y.at<double>(i, 0) << endl;
//            Y.at<double>(i, 0) = Y.at<double>(i, 0) + storeData.speeds[k] * pow(storeData.speed_times[k], i);
//        }
//    }
//    solve(X, Y, storeData.A);
//}
//
//float Rune::after_denoise(double time) {
//    double theta = 0;
//    for(int i =0;i < data.denoise_samplesize;i++){
//        theta = theta+storeData.A.at<double>(i)*pow(time,i);
//    }
//
//    return theta;
//}
//void Rune::collect_data()  {
//    double time1 = storeData.speed_times[0];
//    double time2 = storeData.speed_times[storeData.speed_times.size() - 1];
//    double all_time = time2 - time1;
//    double start_time = time1 +all_time*0.05;
//    double end_time = time2 -all_time*0.1;
//    for(int i = 0 ;i < storeData.speed_times.size() ;i++){
//        if(storeData.speed_times[i] > start_time && storeData.speed_times[i] < end_time) {
//            storeData.process_speeds.push_back(storeData.speeds[i]);
//            storeData.process_times.push_back(storeData.speed_times[i]);
//        }
//    }
//
//}

void Rune::fit_way() {
    cout << "fitting" << endl;
    mutex2.lock();
    now_is_fitting = 1;
    vector<double> speeds = storeData.speeds;
    vector<double> speed_times = storeData.speed_times;
    now_is_fitting =0;
    mutex2.unlock();
    int sampelsize = speed_times.size();
    if(sampelsize >1) {
        Mat y(sampelsize, 1, CV_64FC1);
        Mat M(sampelsize, 3, CV_64FC1);
        int i = 0;
        while (i < sampelsize) {
            y.at<double>(i, 0) = speeds[i];
            double draw_X = int(speed_times[i] * 100) % 2000;
            circle(picture, Point2f(draw_X, speeds[i] * 100), 1, Scalar(0, 255, 0), 1);
            for (int k = 0; k < 3; k++) {
                if (k == 0) {
                    M.at<double>(i, k) = cos(speed_times[i] * storeData.frequency);
                } else if (k == 1) {
                    M.at<double>(i, k) = sin(speed_times[i] * storeData.frequency);
                } else {
                    M.at<double>(i, k) = 1;
                }
            }
            i++;
        }
        Mat x = (M.t() * M).inv() * (M.t() * y);
        double A = x.at<double>(0, 0);
        double B = x.at<double>(0, 1);
        double D = x.at<double>(0, 2);
        double C = pow((A * A + B * B), 0.5);
        double theta;
        if (A >= 0) {
            theta = atan(-1 * B / A);
        } else {
            theta = atan(-1 * B / A) + 3.1415926;
        }
        if (1.8 < C + D < 2.5) {
            storeData.C = C;
            storeData.theta = theta;
            storeData.D = D;
            is_fitted = 1;
        }
    }
}
void Rune::fitting(){
    picture = Mat(1000,2000,CV_8UC3,Scalar(0,0,0));
    while(true) {
        if (storeData.speed_times.size() > 50) {
            //cout<<"amazing"<<endl;
            double time =(storeData.speed_times[storeData.speed_times.size() - 1] - storeData.speed_times[0]) ;
            if(1.8 >time && time >= 1.5 && fit_one ==1){
                cout<<"1.5-1.7"<<endl;
                fit_way();
                fit_one = 0;
            }else if(time >= 2.5){
                cout<<"2.5-"<<endl;
                fit_way();
                cout<<"after_fitted"<<endl;
                mutex2.lock();
                now_is_fitting =1;
                int time_size = int(storeData.speed_times.size() / 4);
                for (int i = 0; i < time_size; i++) {
                    storeData.speed_times.erase(storeData.speed_times.begin());
                    storeData.speeds.erase(storeData.speeds.begin());
                }
                now_is_fitting =0;
                mutex2.unlock();
                if( storeData.C+storeData.D < 1.8 && storeData.C +storeData.D > 2.5) {
                    mutex2.lock();
                    queue_clear(storeData.times);
                    queue_clear(storeData.angles);
                    storeData.speed_times.clear();
                    storeData.speeds.clear();
                    mutex2.unlock();
                }
            }else{
                if(data.debug) {
                   // cout << "data capacity is too little" << endl;
                }
            }
        }else{
        }

    }
}
//void Rune::fit_phase() {
//
//    double last_angle;
//    if(p_times.size() <=2) {
//        p_times.push(storeData.targets[0].m_time);
//        p_angles.push(storeData.targets[0].m_angle);
//    }else if(p_times.back() - p_times.front() < 1000){
//        p_times.push(storeData.targets[0].m_time);
//        p_angles.push(storeData.targets[0].m_angle);
//    }else{
//        double sample_size;
//        sample_size = p_times.size();
//        Mat m_angle(1, sample_size, CV_64FC1);
//        Mat m_time(1, sample_size, CV_64FC1);
//
//
//        for(int i =0;i<sample_size;i++){
//            if(i ==0) {
//                cout<<p_times.front()<<endl;
//                m_angle.at<double>(0, i) = float(p_angles.front());
//                m_time.at<double>(0, i) = float(p_times.front());
//                last_angle = p_angles.front();
//            }else {
//                if(p_times.front() - last_angle > 340) {
//                    m_angle.at<double>(0, i) = p_angles.front() - 360;
//                }else if(p_times.front() - last_angle <-340){
//                    m_angle.at<double>(0,i)=p_angles.front() +360;
//                }else{
//                    m_angle.at<double>(0,i) = p_angles.front();
//                }
//                m_time.at<double>(0, i) = p_times.front();
//                last_angle = p_angles.front();
//            }
//            p_times.pop();
//            p_angles.pop();
//        }
//        cv::Scalar mean_tmp;
//        cv::Scalar stddev_tmp;
//        double stddev=100.0;
//        Mat difference(1,sample_size,CV_64FC1);
//        Mat best_difference(1,sample_size,CV_64FC1);
//        for( double i=0;i<CV_PI*2/1.92;i+=0.001){
//            for( int j=0;j<sample_size;j++) {
//                double nowtime=m_time.at<double>(j)/1000;
//                double nowangle=m_angle.at<double>(j);
//                if ( storeData.direction == 1) {
//                    double nowangle1=-(storeData.C / 1.92 * sin(1.92 * nowtime + i) + storeData.D * nowtime) * 180 / CV_PI;
//                    difference.at<double>(j)=(nowangle1- nowangle);
//                }
//                if( storeData.direction==-1){
//                    double nowangle1=(storeData.C / 1.92 * sin(1.92 * nowtime + i ) + storeData.D * nowtime) * 180 / CV_PI ;
//                    difference.at<double>(j)=(nowangle1- nowangle);
//                }
//            }
//            meanStdDev(difference,mean_tmp,stddev_tmp);
//            if(stddev_tmp[0]<stddev)
//            {
//                storeData.theta=i;
//                stddev=stddev_tmp[0];
//                best_difference =difference;
//            }
//        }
//        cout<<"best_difference:"<<best_difference<<endl;
//        cout<<"phase:"<<storeData.theta<<endl;
//        is_match_phase = 0 ;
//
//    }
//
//
//}

