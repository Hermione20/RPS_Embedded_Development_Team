//
// Created by lwk on 2022/3/15.
//
#include "../Rune.h"



void Rune::big_predict(Mat &im2show,double &predict_x,double &predict_y) {
    bool debug =data.debug;
    if (is_fitted == 1) {
        double predict_time;
        predict_time = data.predict_time + interval_time;
        float w = storeData.frequency;
        float A = storeData.C;
        float theta = storeData.theta;
        float D = storeData.D;
        double draw_X = int((storeData.last_target.m_time + predict_time * 1000) / 10) % 2000;
        circle(picture,
               Point2f(draw_X, (A * cos(w * (storeData.last_target.m_time / 1000 + predict_time) + theta) + D) * 100),
               2,
               Scalar(0, 0, 255), 1);
        namedWindow("picture",0);
        resizeWindow("picture",800,500);
        imshow("picture",picture);
        float fore_angle = A / w * (sin(w * storeData.last_target.
                m_time / 1000 + theta)) + D * storeData.last_target.m_time / 1000;

        float latter_angle = A / w * (sin(w * (storeData.last_target.m_time / 1000 + predict_time) + theta)) +
                             D * (storeData.last_target.m_time / 1000 + predict_time);
        float aggregat_angle = fabs(latter_angle - fore_angle) * 180 / CV_PI;
        if (storeData.direction == 1) {
            storeData.predict_angle = storeData.last_target.m_angle - aggregat_angle;
        } else if (storeData.direction == -1) {
            storeData.predict_angle = storeData.last_target.m_angle + aggregat_angle;
        } else {
            storeData.predict_angle = storeData.last_target.m_angle;
        }

        float angle;
        float distance = storeData.distance;
        float x = R_center.x;
        float y = R_center.y;

        if (storeData.predict_angle > 360)
            storeData.predict_angle = storeData.predict_angle - 360;
        if (storeData.predict_angle < 0)
            storeData.predict_angle = storeData.predict_angle + 360;

        if (storeData.predict_angle < 90 && storeData.predict_angle >= 0) {
            angle = storeData.predict_angle * CV_PI / 180;
            predict_x = x + pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
            predict_y = y - pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
        }
        if (storeData.predict_angle < 180 && storeData.predict_angle > 90) {
            angle = storeData.predict_angle * CV_PI / 180;
            predict_x = x - pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
            predict_y = y - pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
        }
        if (storeData.predict_angle < 270 && storeData.predict_angle > 180) {
            angle = storeData.predict_angle * CV_PI / 180;
            predict_x = x - pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
            predict_y = y + pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
        }
        if (storeData.predict_angle < 360 && storeData.predict_angle > 270) {
            angle = storeData.predict_angle * CV_PI / 180;
            predict_x = x + pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
            predict_y = y + pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
        }
        circle(im2show,Point2f(predict_x,predict_y),10,Scalar(0,255,0),3);
    }
}