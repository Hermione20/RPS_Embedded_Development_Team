#include "../Rune.h"

void Rune::big_run(double m_time_span, Mat& initial_img, double &x, double &y,  int color,Mat &im2show) {
    cout << "--------" << endl;
    storeData.get_time_diff = 0;
    storeData.get_angle_diff = 0;
    auto t1 = chrono::high_resolution_clock::now();
    recognize(initial_img,im2show,color);
    select_r(R_points,im2show);
    auto t2 = chrono::high_resolution_clock::now();
    double time_span = chrono::duration<double,milli>(t2-t1).count();
    cout<<"recognize:"<<time_span<<endl;
    auto t3 =chrono::high_resolution_clock::now();
    if (may_targets.size() == 1) {
        interval_time =0;
        add_up=0;
        storeData.vane =may_targets[0];
        storeData.distance = get_distance(storeData.vane.center,R_center);
        get_angle();
        if(now_is_fitting ==0) {
            get_T_and_A(m_time_span);
            if (storeData.get_time_diff == 1 && storeData.get_angle_diff == 1) {
                get_speed();
            }
        }
        storeData.last_target = storeData.vane;
        storeData.last_target.m_time = m_time_span;
        collect_angles();
        if (ag_of_judge.size() > 20) {
            getdirection();
            ag_of_judge.clear();
            anticlockwise = 0;
            clockwise = 0;
            stop =0;
        }
    }else{
        //cout<<"not find target"<<endl;
        add_up ++;
        interval_time = (m_time_span - storeData.last_target.m_time)/1000 + interval_time;
    }
    auto t4 = chrono::high_resolution_clock::now();
    double time_span1 = chrono::duration<double,milli>(t4-t3).count();
    cout<<"process_data:"<<time_span1<<endl;

    if(add_up<3){
        big_predict(im2show,x,y);
    }
    cout<<"add_up:"<<add_up<<endl;
    if(add_up > 10){
        if(data.debug) {
            cout << "clear all" << endl;
        }
        mutex2.lock();
        fit_one = 1;
        queue_clear(storeData.times);
        queue_clear(storeData.angles);
        storeData.speed_times.clear();
        storeData.speeds.clear();
        mutex2.unlock();
    }

    auto t5 = chrono::high_resolution_clock::now();
    double time_span2 = chrono::duration<double,milli>(t5-t4).count();
    cout<<"predict:"<<time_span2<<endl;
    //cv::imshow("m_initial_img",initial_img);
    //this_thread::sleep_for(chrono::milliseconds(10));
}
