//
// Created by lwk on 2022/4/25.
//
#include "../Rune.h"

void Rune::small_run(double m_time_span, Mat& initial_img, double &x, double &y,  int color,Mat &im2show) {

    cout << "--------" << endl;
    storeData.get_time_diff = 0;
    storeData.get_angle_diff = 0;
    recognize(initial_img,im2show,color);
    select_r(R_points,im2show);
    if (may_targets.size() == 1) {
        storeData.vane =may_targets[0];
        storeData.distance = get_distance(storeData.vane.center,R_center);
        interval_time =0;
        add_up=0;
        get_angle();
        collect_angles();
        if (ag_of_judge.size() > 20) {
            cout<<"why"<<endl;
            getdirection();
            ag_of_judge.clear();
            anticlockwise = 0;
            clockwise = 0;
            stop =0;
        }

        storeData.last_target = storeData.vane;
        storeData.last_target.m_time= m_time_span;
    }else{
        add_up ++;
        interval_time =(m_time_span - storeData.last_target.m_time)/1000 + interval_time;
    }
    if(add_up < 3){
        small_predict(im2show,x,y);
    }
    //cv::imshow("im2show", im2show);
    //cv::imshow("m_initial_img",initial_img);
    cout << "--------" << endl;
}