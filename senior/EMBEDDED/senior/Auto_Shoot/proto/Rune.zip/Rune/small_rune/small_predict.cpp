//
// Created by lwk on 2022/3/15.
//
#include "../Rune.h"

void Rune::small_predict(Mat &im2show,double &predict_x,double &predict_y) {
    float angle;
    double aggregat_angle = 60*(data.predict_time + interval_time);
    cout<<"direction:"<<storeData.direction<<endl;
    if (storeData.direction == 1) {
        storeData.predict_angle = storeData.last_target.m_angle - aggregat_angle;
    } else if (storeData.direction == -1) {
        storeData.predict_angle = storeData.last_target.m_angle + aggregat_angle;
    } else {
        storeData.predict_angle = storeData.last_target.m_angle;
    }
    float  distance = storeData.distance;
    float x=R_center.x;
    float y =R_center.y;
    cout<<"predict_angle:"<<storeData.predict_angle<<endl;
    if (storeData.predict_angle > 360)
        storeData.predict_angle = storeData.predict_angle - 360;
    if (storeData.predict_angle < 0)
        storeData.predict_angle = storeData.predict_angle + 360;

    if (storeData.predict_angle < 90 && storeData.predict_angle >= 0) {
        angle = storeData.predict_angle * CV_PI / 180;
        predict_x = x + pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
        predict_y = y - pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
    }
    if (storeData.predict_angle < 180 && storeData.predict_angle > 90) {
        angle = storeData.predict_angle * CV_PI / 180;
        predict_x = x - pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
        predict_y = y - pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
    }
    if (storeData.predict_angle < 270 && storeData.predict_angle > 180) {
        angle = storeData.predict_angle * CV_PI / 180;
        predict_x = x - pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
        predict_y = y + pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
    }
    if (storeData.predict_angle < 360 && storeData.predict_angle > 270) {
        angle = storeData.predict_angle * CV_PI / 180;
        predict_x = x + pow((pow(distance, 2) / (1 + pow(tan(angle), 2))), 0.5);
        predict_y = y + pow(pow(distance * tan(angle), 2) / (1 + pow(tan(angle), 2)), 0.5);
    }
    circle(im2show,Point2f(predict_x,predict_y),10,Scalar(0,255,0),5);
    //circle(im2show,Point2f(rp_with_roi.x,rp_with_roi.y),10,Scalar(0,255,0),5);

}
