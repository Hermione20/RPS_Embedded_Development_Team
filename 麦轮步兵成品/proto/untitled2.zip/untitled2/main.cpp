
#include <iostream>
#include<opencv4/opencv2/opencv.hpp>
#include<opencv4/opencv2/highgui.hpp>
#include <queue>
#include<thread>
#include <chrono>
#include <atomic>
#include "condition_variable"
#include <opencv2/cudaimgproc.hpp>
#include <opencv2/cudafilters.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudawarping.hpp>
#include <opencv2/cudabgsegm.hpp>
#include <opencv2/cudalegacy.hpp>


using namespace std;
using namespace cv;
using namespace ml;
using namespace chrono;

//
//struct armor{
//public:
//    armor(int i,Point2f a){
//        id=i;
//        b=a;
//    }
//    int id;
//    Point2f point2F{1,1};
//    Point2f b;
//    bool operator<(const armor& a)const
//    {
//        return a.id<id;
//    }
//
//};
void f(int i)
{
    std::cout << i << std::endl;
}
int main() {
    Mat elem1 = getStructuringElement( MORPH_RECT, Size(1, 1)  );
    Mat elem2 = getStructuringElement( MORPH_RECT, Size(3, 3) );
    int CudaDevice;
    if(cv::cuda::getCudaEnabledDeviceCount()==0)
    {
        cerr<<endl<<"ERROR: NO CudaEnabledDevice"<<endl;
        exit(2);
    }
    else
    {
        CudaDevice = cv::cuda::getDevice();
        cv::cuda::setDevice(CudaDevice);
    }
    cv:Mat image = cv::imread("2.jpg", cv::IMREAD_COLOR);
    auto t1 = chrono::high_resolution_clock::now();
    Ptr<cuda::Filter> dilateFilter = cuda::createMorphologyFilter( MORPH_DILATE, CV_8U, elem1 );
    auto t2 = chrono::high_resolution_clock::now();
    double time_space = duration<double,milli>(t2-t1).count();
    cout<<"time_space:"<<time_space<<endl;
    cv::cuda::Stream main_stream,first_stream,second_stream;
    while(true){
        auto t5 = chrono::high_resolution_clock::now();
        vector<Mat> channel;
        split(image,channel);
        Mat cpu_mat = channel.at(2)-channel.at(0);
        threshold(cpu_mat,cpu_mat,70,255,THRESH_BINARY);
        dilate(cpu_mat,cpu_mat,elem1);
        auto t6 = chrono::high_resolution_clock::now();
        double time_span2 = duration<double,milli>(t2-t1).count();
        cout<<"time_span2:"<<time_span2<<endl;
        cv::cuda::GpuMat initial_img,binary_img,result_img;
        auto t1 = chrono::high_resolution_clock::now();
        initial_img.upload(image,main_stream);
        auto t2 = chrono::high_resolution_clock::now();
        double time_span = duration<double,milli>(t2-t1).count();
        cout<<"time_span:"<<time_span<<endl;
        std::vector<cuda::GpuMat> channels;
        cv::cuda::split(initial_img, channels,main_stream);
        cuda::GpuMat split_img;
        cv::cuda::addWeighted(channels[2], 1.0, channels[0], -1.0, 0.0, split_img, -1, main_stream);//bgr
        cv::cuda::threshold(split_img, split_img, 70, 255, THRESH_BINARY, main_stream);
        dilateFilter->apply( split_img, split_img ,main_stream);
        auto t3 = chrono::high_resolution_clock::now();
        double time_span1 = duration<double,milli>(t3-t2).count();
        cout<<"time_span1:"<<time_span1<<endl;
        cuda::cvtColor(initial_img,binary_img,COLOR_BGR2GRAY);
        cv::cuda::threshold(binary_img, binary_img, 60, 255, THRESH_BINARY,main_stream);
        dilateFilter->apply( binary_img, binary_img,main_stream );
        cuda::bitwise_and(split_img,binary_img,result_img);
        dilateFilter->apply( result_img, result_img,main_stream );
        Mat show;
        result_img.download(show,main_stream);
        main_stream.waitForCompletion();

        cv::namedWindow("Image",0);
        cv::imshow("Image",show);
        waitKey(1);
    }

    cv::namedWindow("Image",0);
    cv::imshow("Image",image);
    waitKey(0);

////angle_test
//double angle_diff = 289;
//int n = int(angle_diff/72);
//    angle_diff = fabs( (angle_diff - n*72));
//    if(angle_diff >65){
//        angle_diff =fabs(72-angle_diff);
//    }
//cout<<angle_diff<<endl;

//    Parameter parameter;
//
//    parameter.a(small_op);
//
//    test t;
//    t.test1();
//    t.Test();

////取最大值的序列
//    vector<float> speeds;
//    vector<float> speed_times;
//    for(float i = 12;i<300*12;i=i + 12 ){
//        speeds.push_back(fabs(( 2 * sin(2 * i/1000 ) + 2.5)));
//        cout<<i<<endl;
//    }
//    queue<float> a;
//    int j=0;
//    int k=0;
//    for(int i = 0;i<speeds.size(); i++){
//        if(a.size() ==0)
//
//            a.push(speeds[i]);
//        else {
//            if (a.front() < speeds[i]) {
//                cout<<"a.front:"<<a.front()<<endl;
//                a.pop();
//                a.push(speeds[i]);
//                j=i;
//                cout<<"speeds["+ to_string(i)+"]:"<<speeds[i]<<endl;
//            }else{
//                cout<<"speeds["+ to_string(i)+"]:"<<speeds[i]<<endl;
//            }
//        }
//    }
//    for(int i = 0;i<speeds.size(); i++){
//        if(a.size() ==0)
//
//            a.push(speeds[i]);
//        else {
//            if (a.front() > speeds[i]) {
//                cout<<"a.front:"<<a.front()<<endl;
//                a.pop();
//                a.push(speeds[i]);
//                k=i;
//                cout<<"speeds["+ to_string(i)+"]:"<<speeds[i]<<endl;
//            }else{
//                cout<<"speeds["+ to_string(i)+"]:"<<speeds[i]<<endl;
//            }
//        }
//    }
//    cout<<j<<endl;
//    cout<<k<<endl;
//    float T =  fabs(k-j)*12/1000;
//    cout<<T*2<<endl;
//

////三参数拟合
//    int sampelsize =3;
//    Mat y(sampelsize, 1, CV_64FC1);
//    Mat M(sampelsize, 3, CV_64FC1);
//    Mat N;
//    int i = 0;
//    int j = 0;
//    auto t1 = high_resolution_clock::now();
//    while (j < sampelsize) {
//        y.at<double>(j, 0) = 0.75* sin(1.884 * i / 1000 + 2) + 1.305 ;
//        for (int k = 0; k < 3; k++) {
//            if (k == 0) {
//                M.at<double>(j, k) = cos(1.884 * i / 1000);
//            } else if (k == 1) {
//                M.at<double>(j, k) = sin(1.884 * i / 1000);
//            } else {
//                M.at<double>(j, k) = 1;
//            }
//        }
//        i = i + 20;
//        j = j + 1;
//    }
//    Mat x = (M.t() * M).inv() * (M.t() * y);
//    double A = x.at<double>(0, 0);
//    double B = x.at<double>(0, 1);
//    double D = x.at<double>(0, 2);
//    double C = pow((A * A + B * B), 0.5);
//    cout <<"C:"<< C << endl;
//    double theta;
//    if (A >= 0) {
//        theta = atan(-1 * B / A);
//    } else {
//        theta = atan(-1 * B / A) + 3.1415926;
//    }
//    auto t2 = high_resolution_clock::now();
//    double time = duration<double,milli>(t2 - t1).count();
//    cout<<"time:"<<time<<endl;
//    cout << "D:" << D << endl;
//    cout << "differencephase:" << theta << endl;
//

////最小二乘
//    int samplesize = 600;
//    Mat y(samplesize, 1, CV_64FC1);
//    Mat x(samplesize, 1, CV_64FC1);
//    Mat N;
//    double i = 0;
//    int j = 0;
//    while (j < samplesize) {
//        y.at<double>(j, 0) = 0.8 * sin(1.884 * i / 1000 + 0.5) + 2;
//        x.at<double>(j, 0) = i / 1000;
//        i = i + 11;
//        j = j + 1;
//    }
//    //cout<<y<<endl;
//    //cout<<x<<endl;
//    Mat X = Mat::zeros(10, 10, CV_64FC1);
//    Mat Y = Mat::zeros(10, 1, CV_64FC1);
//    Mat A(10, 1, CV_64FC1);
//    for (int i = 0; i < 10; i++)
//        for (int j = 0; j < 10; j++)
//            for (int k = 0; k < samplesize; k++) {
//                //cout<<"x.at<double>(" + to_string(k)+"):"<<x.at<double>(k)<<endl;
//                //cout<<"pow(x.at<double>(k),j+i):"<<pow(x.at<double>(k),j+i)<<endl;
//                X.at<double>(i, j) = X.at<double>(i, j) + pow(x.at<double>(k), j + i);
//            }
//    for (int i = 0; i < 10; i++) {
//        for (int k = 0; k < samplesize; k++) {
//            //cout << Y.at<double>(i, 0) << endl;
//            Y.at<double>(i, 0) = Y.at<double>(i, 0) + y.at<double>(k) * pow(x.at<double>(k), i);
//        }
//        //cout<<"-------"<<endl;double t = 0;
//    }
//
//    solve(X,Y,A);
//    double time = 0;
//
//    double rate = 0;
//    for(int j = 0;j < 600;j++) {
//        double theta1 = 0;
//        double theta2 =0;
//        time = time +10;
//        for (int i = 1; i < 10; i++) {
//            theta1 = theta1 + A.at<double>(i) * pow(time/1000, i);
//        }
//        for(int i =3; i<10;i++){
//            theta2 =theta2 +(i)*(i-1)*(i-2)*A.at<double>(i)*pow(time/1000,i-3);
//        }
//        cout<<rate<<endl;
//        rate = rate + theta2/theta1;
//    }
//    rate = rate /600;
//
//    cout<<"rate"<<sqrt(-rate)<<endl;
//    cout<<0.8 * sin(1.884 * 1+ 0.5) + 2<<endl;
    //cout << X << endl;
    //cout << Y << endl;

////read text
//    FileStorage fin("../camera-param.yml",cv::FileStorage::READ);
//    cout<<fin.isOpened()<<endl;
//    Mat a;
//    fin["Tcb"] >> a;
//    cout<<a<<endl;
//// priority_queue
//    priority_queue<armor> p;  // 变量声明.
//    armor armor1(1,Point2f{1,2});
//    armor armor2(2,Point2f{1,3});
//    armor armor3(2,Point2f{2,2});
//    p.push(armor1); // 插入 10 到队列, top=10
//    p.push(armor2); // 插入 30 到队列, top=30
//    p.push(armor3); // 插入 20 到队列, top=20
//    cout << "可用元素的数量 到 'p' :" << p.size() << endl;
//    while (!p.empty()) {
//        cout << p.top().id << endl;
//        p.pop();
//    }
//////方差最小拟合相位
//    int sample_size = 100;
//    cv::Scalar mean_tmp;
//    cv::Scalar stddev_tmp;
//    double stddev=100.0;
//    int direction =1;
//    double phase;
//    Mat m_time(1,sample_size,CV_64FC1);
//    Mat m_angle(1,sample_size,CV_64FC1);
//    Mat difference(1,sample_size,CV_64FC1);
//    float time=2;
//    for(int k=0;k<sample_size;k++){
//        time=time+0.01;
//        m_angle.at<double>(0,k) = -(0.75 / 1.884 * sin(1.884 * ( time)+0.35) + 1.301 * time) * 180 / CV_PI +50 + static_cast <float> (rand()) / static_cast <float> (RAND_MAX) ;
//        m_time.at<double>(0,k)=time;
//    }
//    auto t1 = high_resolution_clock::now();
//    for( double i=0;i<CV_PI*2/1.92;i+=0.01){
//        for( int j=0;j<sample_size;j++) {
//            double nowtime=m_time.at<double>(j);
//            double nowangle=m_angle.at<double>(j);
//            if ( direction == 1) {
//                double nowangle1=-(0.820 / 1.92 * sin(1.92 * (nowtime )+i) + 1.291 * nowtime) * 180 / CV_PI;
////                cout<<"nowangle1:"<<nowangle1<<endl;
////                cout<<"nowangle:"<<nowangle<<endl;
//                difference.at<double>(j)=(nowangle1- nowangle);
//            }
//            if( direction==-1){
//                double nowangle1=((0.75 / 1.92 * sin(1.92 * nowtime+i)) + 1.301 * nowtime )* 180 / CV_PI ;
//                difference.at<double>(j)=(nowangle1- nowangle);
//            }
//        }
//        meanStdDev(difference,mean_tmp,stddev_tmp);
//        if(stddev_tmp[0]<stddev)
//        {
//            phase = i;
//            stddev=stddev_tmp[0];
//        }
//
//        //cout<<"stddev:"<<stddev<<endl;
//    }
//    auto t2 =high_resolution_clock::now();
//    double time_last = duration<double,milli>(t2-t1).count();
//    cout<<"time_last:"<<time_last<<endl;
//    cout<<phase<<endl;
    return 0;
};


